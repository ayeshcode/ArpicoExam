﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ArpicoFi.Models
{
    public class TransactionModel
    {
        [Key]
        public int CousId { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("First Name")]
        [Required(ErrorMessage = "This Field is required.")]
        [MaxLength(20, ErrorMessage = "Maximum 12 characters only")]
        public string FirstName { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Last Name")]
        [Required(ErrorMessage = "This Field is required.")]
        [MaxLength(20, ErrorMessage = "Maximum 12 characters only")]
        public string LastName { get; set; }

     
        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Nic No")]
        [Required(ErrorMessage = "This Field is required.")]
        public string NicNo { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Address")]
        [Required(ErrorMessage = "This Field is required.")]
        public string Address { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Email")]
        [Required(ErrorMessage = "This Field is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Mobile Number")]
        [Required(ErrorMessage = "This Field is required 10 Numbers.")]
        [RegularExpression(@"^[\+\d]+(?:[\d-.\s()]*)$", ErrorMessage = "Not a valid Mobile number")]
        public string MobileNo { get; set; }

      

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Birthday")]
        [Required(ErrorMessage = "This Field is required.")]
        public string Birthday { get; set; }

    

    }
}
