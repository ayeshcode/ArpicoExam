﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ArpicoTest.Models
{
    public class TransactionModel
    {
        [Key]
        public int TransactionId { get; set; }

        [Column(TypeName = "nvarchar(12)")]
        [DisplayName("First Name")]
        [Required(ErrorMessage = "This Field is required.")]
        [MaxLength(12, ErrorMessage = "Maximum 12 characters only")]
        public string Name { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Nic No")]
        [Required(ErrorMessage = "This Field is required.")]
        public string Nic { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        [DisplayName("Email")]
        [Required(ErrorMessage = "This Field is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Column(TypeName = "nvarchar(11)")]
        [DisplayName("Address")]
        [Required(ErrorMessage = "This Field is required.")]
        [MaxLength(11)]
        public string Address { get; set; }

        [DisplayName("Mobile No")]
        [Required(ErrorMessage = "This Field is required 10 Number.")]

        [RegularExpression(@"^[\+\d]+(?:[\d-.\s()]*)$", ErrorMessage = "Not a valid Mobile number")]
        public String Phone { get; set; }

        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime Date { get; set; }
    }
}
